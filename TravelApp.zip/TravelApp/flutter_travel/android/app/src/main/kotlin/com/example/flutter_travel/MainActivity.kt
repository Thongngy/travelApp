package com.example.flutter_travel

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
